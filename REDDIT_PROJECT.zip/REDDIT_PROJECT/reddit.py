#!/usr/bin/env python3
"""
Reddit User Persona Generator with Gemini Integration

This script scrapes a Reddit user's profile and generates a comprehensive user persona
based on their posts, comments, and activity patterns using Google's Gemini AI.

Modified to use Gemini instead of OpenAI
"""

import requests
import json
import re
import time
from datetime import datetime, timezone
from collections import Counter, defaultdict
from typing import Dict, List, Any, Optional
import argparse
import sys
import os
from dataclasses import dataclass

# Install with: pip install google-generativeai
try:
    import google.generativeai as genai
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False
    print("Warning: google-generativeai not installed. Install with: pip install google-generativeai")

@dataclass
class LLMAnalysisResult:
    """Data class for LLM analysis results"""
    sentiment_score: float
    personality_traits: List[str]
    interests: List[str]
    communication_style: str
    emotional_tone: str
    expertise_areas: List[str]
    confidence_score: float


class GeminiAnalyzer:
    """Gemini-powered text analysis for enhanced persona generation"""
    
    def __init__(self, api_key: str = None, model: str = "gemini-1.5-flash"):
        """Initialize Gemini analyzer with API configuration"""
        # Use the hardcoded API key
        self.api_key = api_key or os.getenv('GEMINI_API_KEY') or "AIzaSyD-zYM-CaBG5cRrLItELEGIZN2LXucmBg4"
        self.model = model
        self.client = None
        
        if self.api_key and GEMINI_AVAILABLE:
            genai.configure(api_key=self.api_key)
            self.client = genai.GenerativeModel(model)
            print("Gemini API initialized successfully")
        else:
            print("Warning: No Gemini API key found or library not installed. Using fallback analysis.")
    
    def analyze_text_batch(self, texts: List[str], 
                          analysis_type: str = "comprehensive") -> LLMAnalysisResult:
        """Analyze batch of texts using Gemini"""
        if not self.client or not texts:
            return self._fallback_analysis(texts)
        
        try:
            combined_text = " ".join(texts[:50])  # Limit for API efficiency
            
            prompt = self._build_analysis_prompt(combined_text, analysis_type)
            
            response = self.client.generate_content(prompt)
            
            if response.text:
                result = self._parse_gemini_response(response.text)
                return result
            else:
                print("Empty response from Gemini. Using fallback analysis.")
                return self._fallback_analysis(texts)
            
        except Exception as e:
            print(f"Gemini analysis failed: {e}. Using fallback analysis.")
            return self._fallback_analysis(texts)
    
    def _build_analysis_prompt(self, text: str, analysis_type: str) -> str:
        """Build analysis prompt for Gemini"""
        return f"""
        You are an expert psychologist and data analyst specializing in digital behavior analysis. 
        Analyze the following Reddit user content to extract psychological insights, personality traits, and behavioral patterns.

        USER CONTENT:
        {text[:3000]}

        Please provide analysis in this exact JSON format (ensure it's valid JSON):
        {{
            "sentiment_score": <float between -1 and 1>,
            "personality_traits": [<list of 5-8 specific traits>],
            "interests": [<list of 8-12 specific interests>],
            "communication_style": "<detailed style description>",
            "emotional_tone": "<overall emotional tone>",
            "expertise_areas": [<list of areas where user shows knowledge>],
            "confidence_score": <float between 0 and 1 for analysis confidence>
        }}

        Focus on:
        - Psychological patterns and personality indicators
        - Communication style and emotional intelligence
        - Subject matter expertise and knowledge areas
        - Social behavior patterns and community engagement style
        - Underlying motivations and values

        Respond ONLY with the JSON object, no additional text.
        """
    
    def _parse_gemini_response(self, response: str) -> LLMAnalysisResult:
        """Parse Gemini response into structured result"""
        try:
            # Clean up response text
            response = response.strip()
            
            # Extract JSON from response
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                json_str = json_match.group()
                data = json.loads(json_str)
                
                return LLMAnalysisResult(
                    sentiment_score=float(data.get('sentiment_score', 0.0)),
                    personality_traits=data.get('personality_traits', []),
                    interests=data.get('interests', []),
                    communication_style=data.get('communication_style', ''),
                    emotional_tone=data.get('emotional_tone', ''),
                    expertise_areas=data.get('expertise_areas', []),
                    confidence_score=float(data.get('confidence_score', 0.5))
                )
            else:
                print("No valid JSON found in Gemini response")
                return self._fallback_analysis([])
                
        except Exception as e:
            print(f"Failed to parse Gemini response: {e}")
            return self._fallback_analysis([])
    
    def _fallback_analysis(self, texts: List[str]) -> LLMAnalysisResult:
        """Fallback analysis when Gemini is unavailable"""
        combined_text = " ".join(texts).lower()
        
        # Basic sentiment analysis
        positive_words = ['good', 'great', 'awesome', 'love', 'excellent', 'amazing']
        negative_words = ['bad', 'terrible', 'hate', 'awful', 'horrible', 'worst']
        
        pos_count = sum(combined_text.count(word) for word in positive_words)
        neg_count = sum(combined_text.count(word) for word in negative_words)
        
        sentiment = (pos_count - neg_count) / max(len(combined_text.split()), 1)
        
        # Basic trait inference
        traits = []
        if 'help' in combined_text or 'support' in combined_text:
            traits.append("Helpful and supportive")
        if 'think' in combined_text or 'opinion' in combined_text:
            traits.append("Thoughtful and opinionated")
        if '?' in combined_text:
            traits.append("Curious and inquisitive")
        
        return LLMAnalysisResult(
            sentiment_score=min(max(sentiment, -1), 1),
            personality_traits=traits or ["Engaged community member"],
            interests=["General discussion", "Community participation"],
            communication_style="Standard Reddit communication style",
            emotional_tone="Neutral to positive",
            expertise_areas=["General knowledge"],
            confidence_score=0.3
        )
    
    def analyze_communication_patterns(self, posts: List[str], 
                                     comments: List[str]) -> Dict[str, Any]:
        """Analyze communication patterns using Gemini"""
        if not self.client:
            return self._basic_communication_analysis(posts, comments)
        
        try:
            sample_posts = posts[:10]
            sample_comments = comments[:20]
            
            prompt = f"""
            Analyze these Reddit posts and comments for communication patterns:
            
            POSTS:
            {' | '.join(sample_posts)[:500]}
            
            COMMENTS:
            {' | '.join(sample_comments)[:500]}
            
            Provide analysis in this exact JSON format:
            {{
                "writing_style": "<formal/informal/technical/casual>",
                "vocabulary_level": "<basic/intermediate/advanced>",
                "emotional_expression": "<reserved/moderate/expressive>",
                "argumentation_style": "<logical/emotional/balanced>",
                "social_orientation": "<individual/community/mixed>",
                "engagement_preference": "<discussion/information/entertainment>"
            }}
            
            Respond ONLY with the JSON object, no additional text.
            """
            
            response = self.client.generate_content(prompt)
            
            if response.text:
                json_match = re.search(r'\{.*\}', response.text, re.DOTALL)
                if json_match:
                    result = json.loads(json_match.group())
                    return result
            
            return self._basic_communication_analysis(posts, comments)
            
        except Exception as e:
            print(f"Communication analysis failed: {e}")
            return self._basic_communication_analysis(posts, comments)
    
    def _basic_communication_analysis(self, posts: List[str], 
                                    comments: List[str]) -> Dict[str, Any]:
        """Basic communication analysis without LLM"""
        all_text = " ".join(posts + comments).lower()
        
        # Basic analysis
        avg_length = len(all_text.split()) / max(len(posts + comments), 1)
        question_ratio = all_text.count('?') / max(len(all_text), 1)
        
        style = "casual" if avg_length < 20 else "detailed"
        vocab = "intermediate"
        expression = "moderate"
        
        return {
            "writing_style": style,
            "vocabulary_level": vocab,
            "emotional_expression": expression,
            "argumentation_style": "balanced",
            "social_orientation": "community",
            "engagement_preference": "discussion"
        }


class RedditPersonaGenerator:
    def __init__(self, api_key: str = None):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })
        
        # Initialize Gemini analyzer
        self.llm_analyzer = GeminiAnalyzer(api_key)
        
        # Data storage
        self.user_data = {
            'username': '',
            'posts': [],
            'comments': [],
            'subreddits': [],
            'karma': {'post': 0, 'comment': 0},
            'account_age': '',
            'activity_patterns': {},
            'language_style': {},
            'interests': [],
            'citations': [],
            'llm_analysis': None,
            'communication_patterns': {}
        }
        
    def extract_username_from_url(self, url: str) -> str:
        """Extract username from Reddit profile URL"""
        patterns = [
            r'reddit\.com/user/([^/]+)',
            r'reddit\.com/u/([^/]+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                return match.group(1)
        
        raise ValueError("Invalid Reddit profile URL format. Please use: https://www.reddit.com/user/USERNAME")
    
    def fetch_user_data(self, username: str) -> Dict[str, Any]:
        """Fetch user data from Reddit API"""
        try:
            # Get user about info
            about_url = f"https://www.reddit.com/user/{username}/about.json"
            about_response = self.session.get(about_url)
            
            if about_response.status_code != 200:
                raise Exception(f"Failed to fetch user data: {about_response.status_code}")
            
            about_data = about_response.json()
            user_info = about_data['data']
            
            # Get user posts
            posts_url = f"https://www.reddit.com/user/{username}/submitted.json?limit=100"
            posts_response = self.session.get(posts_url)
            posts_data = posts_response.json() if posts_response.status_code == 200 else {'data': {'children': []}}
            
            # Get user comments
            comments_url = f"https://www.reddit.com/user/{username}/comments.json?limit=100"
            comments_response = self.session.get(comments_url)
            comments_data = comments_response.json() if comments_response.status_code == 200 else {'data': {'children': []}}
            
            # Process and store data
            self.user_data['username'] = username
            self.user_data['karma']['post'] = user_info.get('link_karma', 0)
            self.user_data['karma']['comment'] = user_info.get('comment_karma', 0)
            self.user_data['account_age'] = self._calculate_account_age(user_info.get('created_utc', 0))
            
            # Process posts
            for post in posts_data['data']['children']:
                post_data = post['data']
                self.user_data['posts'].append({
                    'title': post_data.get('title', ''),
                    'text': post_data.get('selftext', ''),
                    'subreddit': post_data.get('subreddit', ''),
                    'score': post_data.get('score', 0),
                    'created': post_data.get('created_utc', 0),
                    'url': f"https://reddit.com{post_data.get('permalink', '')}"
                })
            
            # Process comments
            for comment in comments_data['data']['children']:
                comment_data = comment['data']
                self.user_data['comments'].append({
                    'text': comment_data.get('body', ''),
                    'subreddit': comment_data.get('subreddit', ''),
                    'score': comment_data.get('score', 0),
                    'created': comment_data.get('created_utc', 0),
                    'url': f"https://reddit.com{comment_data.get('permalink', '')}"
                })
            
            # Store Gemini analysis data
            post_texts = [post['title'] + ' ' + post['text'] for post in self.user_data['posts']]
            comment_texts = [comment['text'] for comment in self.user_data['comments']]
            
            print("Performing Gemini analysis...")
            self.user_data['llm_analysis'] = self.llm_analyzer.analyze_text_batch(
                post_texts + comment_texts
            )
            
            # Enhanced communication analysis
            self.user_data['communication_patterns'] = self.llm_analyzer.analyze_communication_patterns(
                post_texts, comment_texts
            )
            
            return self.user_data
            
        except Exception as e:
            print(f"Error fetching user data: {e}")
            return None
    
    def _calculate_account_age(self, created_utc: float) -> str:
        """Calculate account age from UTC timestamp"""
        if not created_utc:
            return "Unknown"
        
        created_date = datetime.fromtimestamp(created_utc, timezone.utc)
        now = datetime.now(timezone.utc)
        age = now - created_date
        
        years = age.days // 365
        months = (age.days % 365) // 30
        
        if years > 0:
            return f"{years} year{'s' if years > 1 else ''}, {months} month{'s' if months > 1 else ''}"
        elif months > 0:
            return f"{months} month{'s' if months > 1 else ''}"
        else:
            return f"{age.days} day{'s' if age.days > 1 else ''}"
    
    def analyze_activity_patterns(self) -> Dict[str, Any]:
        """Analyze user's activity patterns"""
        subreddit_counts = Counter()
        posting_times = []
        
        # Analyze subreddit activity
        for post in self.user_data['posts']:
            subreddit_counts[post['subreddit']] += 1
            posting_times.append(post['created'])
        
        for comment in self.user_data['comments']:
            subreddit_counts[comment['subreddit']] += 1
            posting_times.append(comment['created'])
        
        # Get top subreddits
        top_subreddits = subreddit_counts.most_common(10)
        
        # Analyze posting frequency
        total_posts = len(self.user_data['posts']) + len(self.user_data['comments'])
        
        patterns = {
            'most_active_subreddits': top_subreddits,
            'total_activity': total_posts,
            'post_to_comment_ratio': len(self.user_data['posts']) / max(len(self.user_data['comments']), 1),
            'average_post_score': sum(p['score'] for p in self.user_data['posts']) / max(len(self.user_data['posts']), 1),
            'average_comment_score': sum(c['score'] for c in self.user_data['comments']) / max(len(self.user_data['comments']), 1)
        }
        
        return patterns
    
    def analyze_language_style(self) -> Dict[str, Any]:
        """Analyze user's language style and communication patterns"""
        all_text = []
        
        # Collect all text content
        for post in self.user_data['posts']:
            all_text.append(post['title'] + ' ' + post['text'])
        
        for comment in self.user_data['comments']:
            all_text.append(comment['text'])
        
        combined_text = ' '.join(all_text).lower()
        
        # Basic language analysis
        word_count = len(combined_text.split())
        avg_words_per_post = word_count / max(len(all_text), 1)
        
        # Check for common patterns
        question_marks = combined_text.count('?')
        exclamation_marks = combined_text.count('!')
        
        # Sentiment indicators (basic)
        positive_words = ['good', 'great', 'awesome', 'love', 'like', 'amazing', 'excellent', 'perfect']
        negative_words = ['bad', 'terrible', 'hate', 'awful', 'horrible', 'worst', 'sucks', 'disappointed']
        
        positive_count = sum(combined_text.count(word) for word in positive_words)
        negative_count = sum(combined_text.count(word) for word in negative_words)
        
        return {
            'total_word_count': word_count,
            'average_words_per_post': avg_words_per_post,
            'question_frequency': question_marks,
            'exclamation_frequency': exclamation_marks,
            'positive_sentiment_score': positive_count,
            'negative_sentiment_score': negative_count,
            'sentiment_ratio': positive_count / max(negative_count, 1)
        }
    
    def extract_interests(self) -> List[str]:
        """Extract user interests from their activity using Gemini enhancement"""
        interests = []
        
        # Get Gemini-identified interests
        if self.user_data.get('llm_analysis'):
            llm_interests = self.user_data['llm_analysis'].interests
            interests.extend(llm_interests[:10])  # Top 10 Gemini interests
        
        # Traditional subreddit-based analysis
        subreddit_counts = Counter()
        
        # Analyze subreddit participation
        for post in self.user_data['posts']:
            subreddit_counts[post['subreddit']] += 1
        
        for comment in self.user_data['comments']:
            subreddit_counts[comment['subreddit']] += 1
        
        # Map subreddits to interests
        interest_mapping = {
            'programming': ['programming', 'coding', 'python', 'javascript', 'webdev', 'learnprogramming'],
            'gaming': ['gaming', 'games', 'pcgaming', 'nintendo', 'playstation', 'xbox'],
            'technology': ['technology', 'tech', 'gadgets', 'android', 'apple', 'computers'],
            'entertainment': ['movies', 'television', 'music', 'books', 'netflix', 'spotify'],
            'fitness': ['fitness', 'gym', 'bodybuilding', 'running', 'yoga', 'nutrition'],
            'finance': ['personalfinance', 'investing', 'stocks', 'cryptocurrency', 'bitcoin'],
            'education': ['university', 'college', 'studytips', 'academia', 'learning'],
            'lifestyle': ['lifehacks', 'productivity', 'selfimprovement', 'meditation']
        }
        
        for interest, subreddits in interest_mapping.items():
            for subreddit in subreddits:
                if subreddit in subreddit_counts:
                    interests.append(interest)
                    break
        
        # Add top subreddits as interests
        for subreddit, count in subreddit_counts.most_common(5):
            if count > 2:  # Only if they're reasonably active
                interests.append(f"r/{subreddit}")
        
        return list(set(interests))
    
    def generate_persona(self) -> Dict[str, Any]:
        """Generate comprehensive user persona"""
        activity_patterns = self.analyze_activity_patterns()
        language_style = self.analyze_language_style()
        interests = self.extract_interests()
        
        # Generate persona characteristics
        persona = {
            'username': self.user_data['username'],
            'account_age': self.user_data['account_age'],
            'karma_scores': self.user_data['karma'],
            'activity_level': self._categorize_activity_level(activity_patterns['total_activity']),
            'primary_interests': interests[:5],
            'most_active_communities': [subreddit for subreddit, count in activity_patterns['most_active_subreddits'][:5]],
            'communication_style': self._analyze_communication_style(language_style),
            'engagement_pattern': self._analyze_engagement_pattern(activity_patterns),
            'personality_traits': self._infer_personality_traits(language_style, activity_patterns),
            'content_preferences': self._analyze_content_preferences(),
            'social_behavior': self._analyze_social_behavior(activity_patterns),
            'llm_analysis': self.user_data.get('llm_analysis'),
            'communication_patterns': self.user_data.get('communication_patterns')
        }
        
        return persona
    
    def _categorize_activity_level(self, total_activity: int) -> str:
        """Categorize user activity level"""
        if total_activity > 100:
            return "Very Active"
        elif total_activity > 50:
            return "Active"
        elif total_activity > 20:
            return "Moderate"
        else:
            return "Casual"
    
    def _analyze_communication_style(self, language_style: Dict) -> Dict[str, str]:
        """Analyze communication style using Gemini enhancement"""
        style = {}
        
        # Get Gemini analysis if available
        if self.user_data.get('llm_analysis'):
            llm_style = self.user_data['llm_analysis'].communication_style
            style['gemini_analysis'] = llm_style
        
        # Get detailed communication patterns
        if self.user_data.get('communication_patterns'):
            patterns = self.user_data['communication_patterns']
            style['writing_style'] = patterns.get('writing_style', 'casual')
            style['vocabulary_level'] = patterns.get('vocabulary_level', 'intermediate')
            style['emotional_expression'] = patterns.get('emotional_expression', 'moderate')
        
        # Traditional analysis
        if language_style['average_words_per_post'] > 50:
            style['verbosity'] = "Verbose - tends to write detailed, lengthy responses"
        elif language_style['average_words_per_post'] > 20:
            style['verbosity'] = "Moderate - balanced between concise and detailed"
        else:
            style['verbosity'] = "Concise - prefers short, to-the-point responses"
        
        # Enhanced tone analysis using Gemini sentiment
        if self.user_data.get('llm_analysis'):
            sentiment = self.user_data['llm_analysis'].sentiment_score
            if sentiment > 0.3:
                style['tone'] = "Positive - generally optimistic and encouraging"
            elif sentiment > -0.3:
                style['tone'] = "Balanced - neutral to slightly positive tone"
            else:
                style['tone'] = "Critical - tends to be more analytical or negative"
        else:
            # Fallback to traditional analysis
            if language_style['sentiment_ratio'] > 2:
                style['tone'] = "Positive - generally optimistic and encouraging"
            elif language_style['sentiment_ratio'] > 0.5:
                style['tone'] = "Balanced - neutral to slightly positive tone"
            else:
                style['tone'] = "Critical - tends to be more analytical or negative"
        
        # Interaction style
        if language_style['question_frequency'] > 10:
            style['interaction'] = "Inquisitive - asks many questions, seeks information"
        elif language_style['exclamation_frequency'] > 15:
            style['interaction'] = "Enthusiastic - uses exclamations, shows excitement"
        else:
            style['interaction'] = "Straightforward - direct communication style"
        
        return style
    
    def _analyze_engagement_pattern(self, activity_patterns: Dict) -> Dict[str, str]:
        """Analyze user engagement patterns"""
        engagement = {}
        
        # Posting vs commenting behavior
        ratio = activity_patterns['post_to_comment_ratio']
        if ratio > 0.5:
            engagement['content_creation'] = "Content Creator - frequently posts original content"
        elif ratio > 0.2:
            engagement['content_creation'] = "Balanced - mix of posting and commenting"
        else:
            engagement['content_creation'] = "Commenter - primarily engages through comments"
        
        # Community involvement
        if len(activity_patterns['most_active_subreddits']) > 10:
            engagement['community_involvement'] = "Wide-ranging - participates in many communities"
        elif len(activity_patterns['most_active_subreddits']) > 5:
            engagement['community_involvement'] = "Moderate - active in several communities"
        else:
            engagement['community_involvement'] = "Focused - concentrates on few communities"
        
        return engagement
    
    def _infer_personality_traits(self, language_style: Dict, 
                                 activity_patterns: Dict) -> List[str]:
        """Infer personality traits using Gemini enhancement"""
        traits = []
        
        # Get Gemini-identified traits
        if self.user_data.get('llm_analysis'):
            llm_traits = self.user_data['llm_analysis'].personality_traits
            traits.extend(llm_traits[:8])  # Top 8 Gemini traits
        
        # Traditional analysis for additional traits
        if activity_patterns['total_activity'] > 100:
            traits.append("Highly engaged with online communities")
        
        if activity_patterns['post_to_comment_ratio'] > 0.3:
            traits.append("Comfortable sharing original content")
        
        # Based on language style
        if language_style['question_frequency'] > 5:
            traits.append("Curious and inquisitive")
        
        if language_style['sentiment_ratio'] > 1.5:
            traits.append("Generally optimistic")
        
        if language_style['average_words_per_post'] > 30:
            traits.append("Thoughtful and detailed in responses")
        
        # Add expertise areas from Gemini
        if self.user_data.get('llm_analysis'):
            expertise = self.user_data['llm_analysis'].expertise_areas
            for area in expertise[:3]:  # Top 3 expertise areas
                traits.append(f"Knowledgeable in {area}")
        
        return list(set(traits))
    
    def _analyze_content_preferences(self) -> Dict[str, Any]:
        """Analyze content preferences"""
        preferences = {
            'post_types': [],
            'discussion_topics': [],
            'engagement_triggers': []
        }
        
        # Analyze post types
        text_posts = sum(1 for post in self.user_data['posts'] if post['text'])
        link_posts = len(self.user_data['posts']) - text_posts
        
        if text_posts > link_posts:
            preferences['post_types'].append("Text/Discussion posts")
        else:
            preferences['post_types'].append("Link sharing")
        
        # Most engaging content (by score)
        top_posts = sorted(self.user_data['posts'], key=lambda x: x['score'], reverse=True)[:3]
        top_comments = sorted(self.user_data['comments'], key=lambda x: x['score'], reverse=True)[:3]
        
        preferences['top_performing_content'] = {
            'posts': [(post['title'], post['score'], post['subreddit']) for post in top_posts],
            'comments': [(comment['text'][:100] + '...', comment['score'], comment['subreddit']) for comment in top_comments]
        }
        
        return preferences
    
    def _analyze_social_behavior(self, activity_patterns: Dict) -> Dict[str, str]:
        """Analyze social behavior patterns"""
        behavior = {}
        
        # Community loyalty
        top_subreddit_count = activity_patterns['most_active_subreddits'][0][1] if activity_patterns['most_active_subreddits'] else 0
        total_activity = activity_patterns['total_activity']
        
        if top_subreddit_count > total_activity * 0.5:
            behavior['community_loyalty'] = "Highly loyal - concentrates activity in favorite communities"
        elif top_subreddit_count > total_activity * 0.3:
            behavior['community_loyalty'] = "Moderately loyal - has preferred communities but explores others"
        else:
            behavior['community_loyalty'] = "Explorer - spreads activity across many communities"
        
        # Engagement quality
        avg_post_score = activity_patterns['average_post_score']
        avg_comment_score = activity_patterns['average_comment_score']
        
        if avg_post_score > 10 or avg_comment_score > 5:
            behavior['content_quality'] = "High quality - content generally well-received"
        elif avg_post_score > 2 or avg_comment_score > 1:
            behavior['content_quality'] = "Moderate quality - decent community reception"
        else:
            behavior['content_quality'] = "Variable quality - mixed community reception"
        
        return behavior
    
    def generate_citations(self, persona: Dict) -> List[Dict]:
        """Generate citations for persona characteristics"""
        citations = []
        
        # Citation for interests
        if persona['primary_interests']:
            citations.append({
                'characteristic': 'Primary Interests',
                'evidence': f"Based on activity in subreddits: {', '.join(persona['most_active_communities'])}",
                'sources': [post['url'] for post in self.user_data['posts'][:3]]
            })
        
        # Citation for communication style
        if persona['communication_style']:
            citations.append({
                'characteristic': 'Communication Style',
                'evidence': f"Analyzed from {len(self.user_data['posts'])} posts and {len(self.user_data['comments'])} comments",
                'sources': [comment['url'] for comment in self.user_data['comments'][:3]]
            })
        
        # Citation for personality traits
        if persona['personality_traits']:
            citations.append({
                'characteristic': 'Personality Traits',
                'evidence': f"Derived from Gemini LLM analysis and activity patterns across {len(self.user_data['posts'])} posts and {len(self.user_data['comments'])} comments",
                'sources': [post['url'] for post in self.user_data['posts'][:2]] + [comment['url'] for comment in self.user_data['comments'][:2]]
            })
        
        return citations
    
    def generate_persona_report(self, persona: Dict) -> str:
        """Generate a formatted persona report"""
        report = f"# Reddit User Persona Report for u/{persona['username']}\n\n"
        
        report += "## Basic Information\n"
        report += f"- **Username**: u/{persona['username']}\n"
        report += f"- **Account Age**: {persona['account_age']}\n"
        report += f"- **Karma Scores**:\n"
        report += f"  - Post Karma: {persona['karma_scores']['post']}\n"
        report += f"  - Comment Karma: {persona['karma_scores']['comment']}\n"
        report += f"- **Activity Level**: {persona['activity_level']}\n\n"
        
        report += "## Online Behavior\n"
        report += f"- **Most Active Communities**: {', '.join(f'r/{sub}' for sub in persona['most_active_communities'])}\n"
        report += f"- **Primary Interests**: {', '.join(persona['primary_interests'])}\n"
        report += "- **Engagement Pattern**:\n"
        for key, value in persona['engagement_pattern'].items():
            report += f"  - {key.replace('_', ' ').title()}: {value}\n"
        report += "- **Social Behavior**:\n"
        for key, value in persona['social_behavior'].items():
            report += f"  - {key.replace('_', ' ').title()}: {value}\n\n"
        
        report += "## Communication Profile\n"
        report += "- **Communication Style**:\n"
        for key, value in persona['communication_style'].items():
            report += f"  - {key.replace('_', ' ').title()}: {value}\n"
        report += "- **Communication Patterns**:\n"
        for key, value in persona['communication_patterns'].items():
            report += f"  - {key.replace('_', ' ').title()}: {value}\n\n"
        
        report += "## Psychological Profile\n"
        report += f"- **Personality Traits**: {', '.join(persona['personality_traits'])}\n"
        if persona['llm_analysis']:
            report += f"- **Sentiment Score**: {persona['llm_analysis'].sentiment_score:.2f}\n"
            report += f"- **Emotional Tone**: {persona['llm_analysis'].emotional_tone}\n"
            report += f"- **Expertise Areas**: {', '.join(persona['llm_analysis'].expertise_areas)}\n"
            report += f"- **Analysis Confidence**: {(persona['llm_analysis'].confidence_score * 100):.1f}%\n\n"
        
        report += "## Content Preferences\n"
        report += f"- **Preferred Post Types**: {', '.join(persona['content_preferences']['post_types'])}\n"
        report += "- **Top Performing Content**:\n"
        report += "  - Top Posts:\n"
        for title, score, subreddit in persona['content_preferences']['top_performing_content']['posts']:
            report += f"    - {title[:50]}... (Score: {score}, r/{subreddit})\n"
        report += "  - Top Comments:\n"
        for text, score, subreddit in persona['content_preferences']['top_performing_content']['comments']:
            report += f"    - {text[:50]}... (Score: {score}, r/{subreddit})\n\n"
        
        report += "## Citations\n"
        citations = self.generate_citations(persona)
        for i, citation in enumerate(citations, 1):
            report += f"{i}. **{citation['characteristic']}**\n"
            report += f"   - Evidence: {citation['evidence']}\n"
            report += f"   - Sources: {', '.join(citation['sources'][:3])}\n\n"
        
        return report
    
    def save_persona_report(self, persona: Dict, output_file: str):
        """Save persona report to file"""
        try:
            report = self.generate_persona_report(persona)
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(report)
            print(f"Persona report saved to {output_file}")
        except Exception as e:
            print(f"Error saving persona report: {e}")

def main():
    parser = argparse.ArgumentParser(description="Generate Reddit user persona using Gemini AI")
    parser.add_argument("username", help="Reddit username or profile URL")
    parser.add_argument("--output", default="persona_report.md", help="Output file for persona report")
    parser.add_argument("--api-key", help="Gemini API key (optional, can use GEMINI_API_KEY env variable)")
    
    args = parser.parse_args()
    
    # Initialize generator
    generator = RedditPersonaGenerator(args.api_key)
    
    # Handle username or URL input
    username = args.username
    if "reddit.com" in username:
        try:
            username = generator.extract_username_from_url(username)
        except ValueError as e:
            print(f"Error: {e}")
            sys.exit(1)
    
    print(f"Generating persona for u/{username}...")
    
    # Fetch and analyze data
    user_data = generator.fetch_user_data(username)
    if not user_data:
        print("Failed to fetch user data. Exiting.")
        sys.exit(1)
    
    # Generate and save persona
    persona = generator.generate_persona()
    generator.save_persona_report(persona, args.output)
    
    print("Persona generation complete!")

if __name__ == "__main__":
    main()
    